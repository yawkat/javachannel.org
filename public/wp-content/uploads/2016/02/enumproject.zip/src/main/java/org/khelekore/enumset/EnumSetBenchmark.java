package org.khelekore.enumset;

import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.Benchmark;

public class EnumSetBenchmark {

    @Benchmark
    public void testRegular() throws InterruptedException {
	SmallEnum s = SmallEnum.A;
	boolean isA = s.isA ();
	boolean isB = s.isB ();
	boolean isC = s.isC ();
	boolean res = isA | isB | isC;
    }

    @Benchmark
    public void testJumbo() throws InterruptedException {
	Token t = Token.WHITESPACE;
	boolean isWhitespace = t.isWhitespace ();
	boolean isIdentifier = t.isIdentifier ();
	boolean isKeyword = t.isKeyword ();
	boolean isLiteral = t.isLiteral ();
	boolean isSeparator = t.isSeparator ();
	boolean isOperator = t.isOperator ();
	boolean isBitOrShiftOperator = t.isBitOrShiftOperator ();
	boolean res =
	    isWhitespace | isIdentifier | isKeyword | isLiteral |
	    isSeparator | isOperator | isBitOrShiftOperator;
    }

    public static void main (String[] args) throws IOException {
	List<Set<SmallEnum>> tokens = new ArrayList<> ();
	for (int i = 0; i < 1_000_000; i++) {
	    //Set<Token> s = EnumSet.noneOf (Token.class);
	    //Set<SmallEnum> s = new HashSet<> ();
	    Set<SmallEnum> s = EnumSet.noneOf (SmallEnum.class);
	    s.add (SmallEnum.A);
	    s.add (SmallEnum.B);
	    s.add (SmallEnum.C);
	    tokens.add (s);
	}
	System.in.read ();
    }
}

package org.khelekore.enumset;

import java.util.EnumSet;
import java.util.Set;
import java.util.HashSet;

public enum SmallEnum {
    A, B, C;

    private static final Set<SmallEnum> notA =
	of (B, C);

    private static final Set<SmallEnum> notB =
	of (A, C);

    private static final Set<SmallEnum> notC =
	of (A, B);

    private static Set<SmallEnum> of (SmallEnum t, SmallEnum... tokens) {
	return EnumSet.of (t, tokens);
    }

    private static Set<SmallEnum> of_alt (SmallEnum t, SmallEnum... tokens) {
	HashSet<SmallEnum> ret = new HashSet<> ();
	ret.add (t);
	for (SmallEnum tt : tokens)
	    ret.add (tt);
	return ret;
    }

    public boolean isA () {
	return !notA.contains (this);
    }

    public boolean isB () {
	return !notB.contains (this);
    }

    public boolean isC () {
	return !notC.contains (this);
    }
}